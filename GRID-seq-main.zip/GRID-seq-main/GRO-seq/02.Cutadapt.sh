cutadapt -a AAAAA -o $2 $1
