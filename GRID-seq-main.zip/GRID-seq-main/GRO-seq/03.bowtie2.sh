bowtie2 -p 16 -x /Share2/home/qiyijun/lhf/Reference/ath -U $1 > $2
