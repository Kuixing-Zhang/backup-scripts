/Share2/home/qiyijun/software/FastQC/fastqc $1
